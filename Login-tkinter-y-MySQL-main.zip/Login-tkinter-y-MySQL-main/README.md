# Login-tkinter-y-MySQL
 sistema de login desarrollado en Python utilizando tkinter para la interfaz gráfica y MySQL como base de datos. Incluye funciones de registro, inicio de sesión y creacion de usuarios.

 bibliotecas necesarias para ejecutar el sistema:
 
 pip install pillow
 pip install mysql-connector-python
