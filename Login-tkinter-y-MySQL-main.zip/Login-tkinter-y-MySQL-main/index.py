
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import mysql.connector

# Colores utilizados en el esquema moderno
DARK_BG = "#1E1E1E"
LIGHT_BG = "#252526"
TEXT_COLOR = "#D4D4D4"
ACCENT_COLOR = "#569CD6"
SECONDARY_ACCENT = "#4EC9B0"
ENTRY_BG = "#2D2D2D"
BUTTON_COLOR = "#0E639C"
ERROR_COLOR = "#F44747"
SUCCESS_COLOR = "#6A9955"
WHITE_BG = "#FFFFFF"
LIGHT_PURPLE_BG = "#E6E6FA"

class LoginSystem:
    def __init__(self, master):
        self.master = master
        self.master.title("Sistema de Login")
        self.master.configure(bg=WHITE_BG)
        self.original_geometry = "780x500"  # Guardar las dimensiones originales
        self.center_window(780, 500)
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.configure_styles()
        
        self.create_widgets()

    def center_window(self, width, height, window=None):
        if window:
            screen_width = window.winfo_screenwidth()
            screen_height = window.winfo_screenheight()
            x = (screen_width // 2) - (width // 2)
            y = (screen_height // 2) - (height // 2)
            window.geometry(f'{width}x{height}+{x}+{y}')
            window.resizable(False, False)  # Deshabilitar redimensionamiento
        else:
            screen_width = self.master.winfo_screenwidth()
            screen_height = self.master.winfo_screenheight()
            x = (screen_width // 2) - (width // 2)
            y = (screen_height // 2) - (height // 2)
            self.master.geometry(f'{width}x{height}+{x}+{y}')
            self.master.resizable(False, False)  # Deshabilitar redimensionamiento

    def configure_styles(self):
        self.style.configure('TFrame', background=WHITE_BG)
        self.style.configure('TLabel', background=WHITE_BG, foreground=TEXT_COLOR, font=('Segoe UI', 12))
        self.style.configure('TEntry', fieldbackground=ENTRY_BG, foreground=TEXT_COLOR, font=('Segoe UI', 12))
        self.style.map('TEntry', fieldbackground=[('focus', LIGHT_BG)])
        self.style.configure('TButton', background=BUTTON_COLOR, foreground=TEXT_COLOR, font=('Segoe UI', 12, 'bold'), padding=7)
        self.style.map('TButton', background=[('active', ACCENT_COLOR)])
        self.style.configure('TCheckbutton', background=WHITE_BG, foreground=TEXT_COLOR, font=('Segoe UI', 12))
        self.style.configure('LightPurpleBg.TFrame', background=LIGHT_PURPLE_BG)

    def create_widgets(self):
        # Marco principal
        main_frame = ttk.Frame(self.master, style='TFrame')
        main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Marco izquierdo con imagen de fondo y títulos
        left_frame = ttk.Frame(main_frame, style='TFrame')
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        image = Image.open("fondo.jpg")
        image = image.resize((502, 600), Image.LANCZOS)
        bg_image = ImageTk.PhotoImage(image)
        
        bg_label = tk.Label(left_frame, image=bg_image, borderwidth=0)
        bg_label.image = bg_image
        bg_label.pack(fill=tk.BOTH, expand=True)

        # Marco derecho con formulario de inicio de sesión
        right_frame = ttk.Frame(main_frame, style='LightPurpleBg.TFrame')
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        login_frame = ttk.Frame(right_frame, padding="20 20 20 20", style='LightPurpleBg.TFrame')
        login_frame.pack(expand=True, fill=tk.BOTH)

        ttk.Label(login_frame, text='Iniciar Sesión', font=("Segoe UI", 28, "bold"), foreground=ACCENT_COLOR, background=LIGHT_PURPLE_BG).pack(pady=30)
        
        self.email_var = tk.StringVar()
        self.password_var = tk.StringVar()

        self.create_entry(login_frame, "Usuario 📧", self.email_var)
        self.create_entry(login_frame, "Contraseña 🔑", self.password_var, show="•")

        self.login_label = ttk.Label(login_frame, text="", font=('Segoe UI', 12), background=LIGHT_PURPLE_BG)
        self.login_label.pack(pady=10)

        ttk.Button(login_frame, text='Iniciar Sesión 🚪', command=self.login).pack(pady=20, fill=tk.X)

        register_label = ttk.Label(login_frame, text='¿No tienes una cuenta? ¡Regístrate!', font=("Segoe UI", 9, "underline"), foreground=SECONDARY_ACCENT, background=LIGHT_PURPLE_BG, cursor="hand2")
        register_label.pack(pady=20)
        register_label.bind("<Button-1>", lambda e: self.open_register())

    def create_entry(self, parent, label_text, var, show=None):
        frame = ttk.Frame(parent, style='LightPurpleBg.TFrame')
        frame.pack(fill=tk.X, pady=10)
        ttk.Label(frame, text=label_text, background=LIGHT_PURPLE_BG).pack(anchor=tk.W)
        entry = ttk.Entry(frame, textvariable=var, show=show, style='TEntry')
        entry.pack(fill=tk.X, pady=(5, 0))
        entry.configure(background=LIGHT_PURPLE_BG)  # Configurar el fondo directamente en la entrada

    def login(self):
        email = self.email_var.get()
        pwd = self.password_var.get()
        
        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="bd_sistema"
            )

            mycursor = mydb.cursor()
            sql = "SELECT FullName FROM Userdetails WHERE EmailID = %s AND Password = %s"
            val = (email, pwd)
            mycursor.execute(sql, val)
            
            result = mycursor.fetchone()
            
            if result:
                self.login_label.config(text=f'Inicio de sesión exitoso, ¡Bienvenido {result[0]}! 🎉', foreground=SUCCESS_COLOR)
            else:
                self.login_label.config(text='Email o contraseña inválida ❌', foreground=ERROR_COLOR)
                self.clear_fields()
            
            mycursor.close()
            mydb.close()
            
        except mysql.connector.Error as err:
            self.login_label.config(text=f"Error de base de datos: {err}", foreground=ERROR_COLOR)

    def clear_fields(self):
        self.email_var.set("")
        self.password_var.set("")

    def open_register(self):
        register_window = tk.Toplevel(self.master)
        register_window.title("Registrarse")
        register_window.configure(bg=WHITE_BG)
        self.center_window(450, 700, register_window)  # Centrar la ventana de registro

        main_frame = ttk.Frame(register_window, padding="20 20 20 20", style='TFrame')
        main_frame.pack(expand=True, fill=tk.BOTH)

        ttk.Label(main_frame, text='Registrarse 📝', font=("Segoe UI", 24, "bold"), foreground=ACCENT_COLOR).pack(pady=20)

        fields = [("Nombre Completo", None), ("Contraseña", "•"), ("Correo Electrónico", None), ("Género", None), ("Edad", None)]
        self.register_vars = [tk.StringVar() for _ in fields]

        for (text, show), var in zip(fields, self.register_vars):
            self.create_entry(main_frame, text, var, show)

        self.terms_var = tk.BooleanVar()
        ttk.Checkbutton(main_frame, text='Acepto los términos y condiciones ✅', variable=self.terms_var, style='TCheckbutton').pack(pady=10)

        self.register_label = ttk.Label(main_frame, text="", font=('Segoe UI', 12), style='TLabel')
        self.register_label.pack(pady=10)

        ttk.Button(main_frame, text='Enviar 🚀', command=self.register).pack(pady=20, fill=tk.X)

    def register(self):
        if all(var.get() for var in self.register_vars) and self.terms_var.get():
            try:
                mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    passwd="",
                    database="bd_sistema"
                )

                mycursor = mydb.cursor()
                mycursor.execute("CREATE TABLE IF NOT EXISTS Userdetails (id INT AUTO_INCREMENT PRIMARY KEY, Name VARCHAR(255), Password VARCHAR(255), EmailID VARCHAR(255), Gender VARCHAR(255), Age VARCHAR(255))")

                sql = "INSERT INTO Userdetails (Name, Password, EmailID, Gender, Age) VALUES (%s, %s, %s, %s, %s)"
                val = tuple(var.get() for var in self.register_vars)
                mycursor.execute(sql, val)

                mydb.commit()

                self.register_label.config(text="¡Registro exitoso! ✅", foreground=SUCCESS_COLOR)
                
                mycursor.close()
                mydb.close()
                
                self.redirect_to_login()
                
            except mysql.connector.Error as err:
                self.register_label.config(text=f"Error de base de datos: {err}", foreground=ERROR_COLOR)
        else:
            self.register_label.config(text="Todos los campos son obligatorios ⚠️", foreground=ERROR_COLOR)

    def redirect_to_login(self):
        for var in self.register_vars:
            var.set("")
        self.terms_var.set(False)
        messagebox.showinfo("Registro", "Registro exitoso. Redirigiendo al login.")
        self.master.deiconify()  # Mostrar la ventana principal (login)
        for window in self.master.winfo_children():
            if isinstance(window, tk.Toplevel):
                window.destroy()  # Cerrar todas las ventanas secundarias (registro)

if __name__ == "__main__":
    root = tk.Tk()
    app = LoginSystem(root)
    root.mainloop()
    
